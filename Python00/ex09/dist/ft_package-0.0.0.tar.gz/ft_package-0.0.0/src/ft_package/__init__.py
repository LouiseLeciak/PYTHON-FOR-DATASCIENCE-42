def count_in_list(lst, item):
    """
    Count how many times `item` appears in `lst`.
    """
    return lst.count(item)
